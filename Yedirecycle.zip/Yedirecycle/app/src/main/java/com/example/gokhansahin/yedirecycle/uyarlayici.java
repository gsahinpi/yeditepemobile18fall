package com.example.gokhansahin.yedirecycle;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class uyarlayici extends RecyclerView.Adapter <uyarlayici.tutucu>
{
   ArrayList<String> asikucuk;

    private LayoutInflater mInflater;

    public uyarlayici(Context con, ArrayList<String> asikucuk) {
        this.asikucuk = asikucuk;
        mInflater = LayoutInflater.from(con);
    }

    class tutucu extends RecyclerView.ViewHolder implements View.OnClickListener
    {TextView tv;
     uyarlayici adp;

        public tutucu(View itemView, uyarlayici adp) {
            super(itemView);
            this.adp = adp;
            tv=itemView.findViewById(R.id.textView);
            tv.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int mPosition = getLayoutPosition();
            String originaltetx=asikucuk.get(mPosition);
            asikucuk.set(mPosition,"Clicked"+ originaltetx);
            adp.notifyDataSetChanged();


        }
    }

    @NonNull
    @Override
    public uyarlayici.tutucu onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mItemView = mInflater.inflate(R.layout.tekitem,parent, false);

        return new tutucu(mItemView,this);
    }

    @Override
    public void onBindViewHolder(@NonNull uyarlayici.tutucu holder, int position) {
        String mCurrent = asikucuk.get(position);
        holder.tv.setText(mCurrent);


    }

    @Override
    public int getItemCount() {
        return asikucuk.size();
    }
}
